#Zhivaldo Fabio
#71200608

print ("="*10, "INI PROGRAM SEDER HANA", "="*10)

gudei = int(input("Masukkan Angka yang ingin di Pangkatkan:\n>>"))
hasil = (gudei**7)

print ("\nAngka anda telah di pangkat kan 7! anda mendapat angka:", hasil)

