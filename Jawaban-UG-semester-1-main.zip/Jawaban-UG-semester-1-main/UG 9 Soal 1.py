print ("="*10, "ALAT PENGHITUNG LINGKARAN SENTOT", "="*10)

diameter = float(input("Masukkan Diameter (Meter) : "))
phi = (3.14)
r = (diameter/2)
keliling = round(2*phi*r)
print ("Jarak yang harus di tempuh :", keliling, "Meter")
